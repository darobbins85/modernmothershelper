<?php
/**
 * Footer template?
 *
 * Is this actually used anywhere? If so, the reference is pretty well hidden.
 *
 * @author              ZeroBSCRM
 * @package             Templates/Portal/Footer
 * @see                 https://jetpackcrm.com/kb/
 */
